print("hello world")
a = 10
